class Sprite {
    constructor({pos, vel, offset}, color) {
        this.pos = pos,

        this.vel = vel,

        this.w = canvas.width/20,
        this.h = canvas.width/6,
        this.c = color,

        this.lastkey

        this.isAttacking = false

        this.swordBox = {
            pos: {
                x: this.pos.x,
                y: this.pos.y
            },
            offset: offset,
            // eventually the size of this should scale with player w
            w: this.w*2.5,
            h: 10
        }
    }

    draw() {
        // draw the player rectangle
        c.fillStyle = this.c
        c.fillRect(this.pos.x, this.pos.y, this.w, this.h)


        // draw the player swordBox
        if (!this.isAttacking) {
            c.fillRect (this.swordBox.pos.x, this.swordBox.pos.y,
                            this.swordBox.w, this.swordBox.h)
        }
       
        
    }

    update() {
        this.draw()
        this.swordBox.pos.x = this.pos.x + this.swordBox.offset.x
        this.swordBox.pos.y = this.pos.y

        this.pos.y += this.vel.y
        this.pos.x += this.vel.x

        // If bottom of sprite is at ground level
        if (this.pos.y + this.h + this.vel.y >= groundLevel)
            this.vel.y = 0
        else 
            this.vel.y += gravity
    }

    attack() {
        // enable isAttacking for 100ms, then disable it again
        console.log('attacking...')
        this.isAttacking = true
        setTimeout(() => {
            this.isAttacking = false
            console.log('done attack.\n')
            console.log()
        }, 100)
        
    }


}
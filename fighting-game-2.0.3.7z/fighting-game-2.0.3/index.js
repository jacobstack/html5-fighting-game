

// Get canvas elements
const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')
// Instantiate canvas size (16:9)
canvas.size = 180
canvas.width = canvas.size * 16
canvas.height = canvas.size * 9

// Consts
const gravity = 0.8
const jumpheight = 20
const groundLevel = canvas.height - 150
const walkspeed = 10

const keys = {
    a: {
        pressed: false
    },
    d: {
        pressed: false
    },
    l: {
        pressed: false
    },
    j: {
        pressed: false
    }
}

// Vars
let lastKey1
let lastkey2


//********Gameplay***********


// Spawn Player
const player = new Sprite({
    pos: {x: 0, y: 0},
    vel: {x: 0, y: 10},
    offset: {x: 0, y: canvas.width/12}
}, "hotpink") 
// Spawn Enemy
const enemy = new Sprite({
    pos: {x: canvas.width-player.w, y: 0},
    vel: {x: 0, y: 10},
    offset: {x: -player.swordBox.w+player.w, y: canvas.width/12}
}, "yellow") 


// Animate the scene
animate()

// ******FUNCTIONS************
function swordCollision({rect1, rect2}
) {
    return (
        rect1.swordBox.pos.x + rect1.swordBox.w >= rect2.pos.x &&
        rect1.swordBox.pos.x <= rect2.pos.x + rect2.w &&
        rect1.swordBox.pos.y + rect1.swordBox.h >= rect2.pos.y &&
        rect1.swordBox.pos.y <= rect2.pos.y + rect2.h
    )
}


function animate() {
    window.requestAnimationFrame(animate)
    //console.log("animating scene")

    // Draw a rectangle representing the canvas
    c.fillStyle = "lightblue"
    c.fillRect(0,0, canvas.width, canvas.height)
    // Draw a rectangle representing the ground
    c.fillStyle = "coral"
    c.fillRect(0, groundLevel, canvas.width, canvas.height)

    // Draw/Update the player & enemy
    player.update()
    enemy.update()

    // Handle player & enemy movement <-->
    player.vel.x = 0
    if (keys.a.pressed && player.lastkey == 'a') {player.vel.x = -walkspeed}
    else if (keys.d.pressed && player.lastkey == 'd') {player.vel.x = walkspeed}

    enemy.vel.x = 0
    if (keys.j.pressed && enemy.lastkey == 'j') {enemy.vel.x = -walkspeed}
    else if (keys.l.pressed && enemy.lastkey == 'l') {enemy.vel.x = walkspeed}

    // Handle sword collisions
    // for player
    if (swordCollision({
        rect1: player,
        rect2: enemy
    }) &&
        player.isAttacking) 
    {
        console.log("player hit enemy")
        player.isAttacking = false
    }

    if (swordCollision({
        rect1: enemy,
        rect2: player
    }) &&
        enemy.isAttacking) 
    {
        console.log("enemy hit player")
        enemy.isAttacking = false
    }
}


// ********EVENT LISTENERS**************

window.addEventListener('keydown', (event) => {
    //console.log(event.key)
    switch (event.key) {
        case 'd':
            keys.d.pressed = true
            player.lastkey = 'd'
            break
        case 'a':
            keys.a.pressed = true
            player.lastkey = 'a'
            break
        case 'l':
            keys.l.pressed = true
            enemy.lastkey = 'l'
            break
        case 'j':
            keys.j.pressed = true
            enemy.lastkey = 'j'
            break
        case 'w':
            player.vel.y = -jumpheight
            break
        case 'i':
            enemy.vel.y = -jumpheight
            break
        case 'c':
            player.attack();
            break
        case 'n':
            enemy.attack();
            break
    }
})
window.addEventListener('keyup', (event) => {
    switch (event.key) {
        case 'd':
            keys.d.pressed = false
            break
        case 'a':
            keys.a.pressed = false
            break
        case 'l':
            keys.l.pressed = false
            break
        case 'j':
            keys.j.pressed = false
            break
    }
})

